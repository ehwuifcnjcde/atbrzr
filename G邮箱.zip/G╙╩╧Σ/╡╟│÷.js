async function main() {

    await utils.update({
        current: {
            flow: content_script_env["flow_name"], script: content_script_env["script_name"],
        },
    });

    if (await utils.checkstop()) {
        return;
    }

    // utils.log(content_script_env)

    await utils.request_customizing("controls", {
        action: "状态变化", status: "正在登出",
    })

    if (/:\/\/accounts\.google\.com\/v\d+\/signin\/identifier/g.test(window.location.href)) {
        await utils.request_customizing("controls", {
            action: "状态变化", status: "已登出",
        })
        await utils.theend();
    } else if (/:\/\/mail\.google\.com\/mail\/u\/0\/.*(?:#(?:inbox)?)?/g.test(window.location.href)) {
        window.location.href = "https://accounts.google.com/Logout"
        const message = {
            action: "准备URL跳转", properties: {
                starting: window.location.href, stations: [{
                    re: new RegExp(/:\/\/accounts\.google\.com\/Logout/g),
                },], destinations: [{
                    re: new RegExp(/:\/\/accounts\.google\.com\/InteractiveLogin/g),
                    flow: content_script_env["flow_name"],
                    script: content_script_env["script_name"],
                },], env: content_script_env, scope: ["current_tab",],
            },
        }
        await utils.request(message)

    } else {
        // const my_account = document.querySelector(`header a[href^="https://accounts.google.com/SignOut"]`);
        // my_account.click()

        let remove_element;
        document.querySelectorAll("div").forEach(el => {
            if (el.textContent.includes("Remove an account") || el.textContent.includes("移除帳戶") || el.textContent.includes("移除账号")) {
                remove_element = el;
            }
        });
        if (remove_element) {
            remove_element.click()
        }
        let xpath = "//ul/li[1]/div/div[2]/*[name()='svg']";
        let nodes = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        // utils.log(nodes)
        for (let i = 0; i < nodes.snapshotLength; i++) {
            nodes.snapshotItem(i).closest("div").click();
            // utils.log(nodes.snapshotItem(i), nodes.snapshotItem(i).closest("div"))

            {
                let xpath = "//span[contains(text(), 'Yes, remove') or contains(text(), '是，') or contains(text(), '移除')]";
                let nodes;
                while (!nodes || nodes.snapshotLength === 0) {
                    nodes = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
                    await utils.sleep(200)
                }
                nodes.snapshotItem(0).click()
            }
        }

        const message = {
            action: "准备URL跳转", properties: {
                starting: window.location.href, stations: [], destinations: [{
                    re: new RegExp(/:\/\/accounts\.google\.com\/v\d+\/signin\/identifier/g),
                    flow: content_script_env["flow_name"],
                    script: content_script_env["script_name"],
                },], env: content_script_env, scope: ["current_tab",],
            },
        }
        await utils.request(message)

    }

}


main()


