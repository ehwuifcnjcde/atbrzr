async function main() {

    await utils.update({
        current: {
            flow: content_script_env["flow_name"], script: content_script_env["script_name"],
        },
    });

    if (await utils.checkstop()) {
        return;
    }

    if (/:\/\/mail\.google\.com\/mail\/u\/0\/.*(?:#(?:inbox)?)?/g.test(window.location.href)) {
        await utils.request_customizing("controls", {
            action: "状态变化", status: "已登录",
        })
        return await utils.theend();
    }

    await utils.request_customizing("controls", {
        action: "状态变化", status: "正在登录",
    })

    await import(browser.runtime.getURL("resource/otplib/buffer.js"));
    await import(browser.runtime.getURL("resource/otplib/index.js"));


    let email = await utils.get_field("输入邮箱：", "email", false, true);
    if (!email.ok) {
        return await utils.theend();
    }

    let password = await utils.get_field("输入密码：", "password", false, true);
    if (!password.ok) {
        return await utils.theend();
    }

    let totp = await utils.get_field("输入TOTP密钥：", "totp", true, true);
    if (!totp.ok) {
        return await utils.theend();
    }

    // utils.log(content_script_env)

    // 输入用户名
    const email_input = document.querySelector("input#identifierId");
    email_input.value = email.data;

    const email_next = document.querySelector(`div[data-primary-action-label="Next"] > div > div:first-child button`);
    email_next.click()

    // 输入密码
    let password_input;
    while (!password_input) {
        password_input = document.querySelector("div#password input");
        await utils.sleep(200)
        if (await utils.checkstop()) {
            return;
        }
    }
    password_input.value = password.data;

    const password_next = document.querySelector(`div#passwordNext button`);
    password_next.click()


    // 输入两步验证码
    if (totp.data) {
        let totp_input;
        while (!totp_input) {
            totp_input = document.querySelector("input#totpPin");
            await utils.sleep(200)
            if (await utils.checkstop()) {
                return;
            }
        }
        const totp_token = window.otplib.authenticator.generate(totp.data.replace(/[\s\r\t\n]+/g, ""));
        totp_input.value = totp_token;
        const totp_ask = document.querySelector(`input[type="checkbox"][checked]`);
        totp_ask.click()
        const totp_next = document.querySelector(`div#totpNext button`);
        totp_next.click()
    }

    const message = {
        action: "准备URL跳转", properties: {
            starting: window.location.href, stations: [], destinations: [{
                re: new RegExp(/:\/\/mail\.google\.com\/mail\/u\/0\/.*(?:#(?:inbox)?)?/g),
                flow: content_script_env["flow_name"],
                script: content_script_env["script_name"],
            },], env: content_script_env, scope: ["current_tab",],
        },
    }
    await utils.request(message)

    // await utils.theend();

}


main()


