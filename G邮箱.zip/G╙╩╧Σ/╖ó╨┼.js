async function main() {

    await utils.update({
        current: {
            flow: content_script_env["flow_name"], script: content_script_env["script_name"],
        },
    });

    if (await utils.checkstop()) {
        return;
    }

    await utils.request_customizing("controls", {
        action: "状态变化", status: "正在发信",
    })

    let files = await utils.get_field_files("拖入附件：", "files", true);
    console.log(files);
    if (!files.ok) {
        return await utils.theend();
    }

    let receiver_emails = await utils.get_field("输入收件者邮箱：", "receiver_emails", false, true);
    console.log(receiver_emails);
    if (!receiver_emails.ok) {
        return await utils.theend();
    }
    if (typeof receiver_emails.data === "string") {
        receiver_emails.data = [receiver_emails.data,]
    }


    {
        let n; // 撰写
        while (!n) {
            await utils.sleep(200)
            if (await utils.checkstop()) {
                return;
            }
            n = utils.xpath_onlyone_visible("//div[@role='navigation']//div[@role='button' and (contains(text(), 'Compose'))]", document)
        }
        utils.scrollToElement(n)
        await utils.sleep(200)
        n.click()

        let form;
        let to_input; // 收件者
        {
            let n;
            while (!n) {
                await utils.sleep(200)
                if (await utils.checkstop()) {
                    return;
                }
                n = utils.xpath_onlyone_visible("//div[@role='dialog']//table//div[text()='Recipients']", document)
                let n2 = utils.xpath_onlyone_visible("//div[@role='dialog']//table//div[@name='to']//input[@type='text']", document)
                if (n2) {
                    n = n2
                }
            }
            utils.scrollToElement(n)
            utils.highlight(n, true)
            await utils.sleep(200)
            to_input = n;
            form = to_input.closest("form");
        }
        to_input.click()
        await utils.sleep(500)
        {
            let n;
            while (!n) {
                await utils.sleep(200)
                if (await utils.checkstop()) {
                    return;
                }
                n = utils.xpath_onlyone_visible("//table//div[@name='to']//input[@type='text']", form)
            }
            utils.scrollToElement(n)
            utils.highlight(n, true)
            await utils.sleep(200)
            to_input = n;
        }
        to_input.value = receiver_emails.data.join(",");


        let subject_input; // 主题
        {
            let n;
            while (!n) {
                await utils.sleep(200)
                if (await utils.checkstop()) {
                    return;
                }
                n = utils.xpath_onlyone_visible("//table//input[@name='subjectbox']", form)
            }
            utils.scrollToElement(n)
            utils.highlight(n, true)
            await utils.sleep(200)
            subject_input = n;
        }
        const subject_format = await utils.get_field("输入主题：", "subject_format", true, true, true, /[\r\t\n]+/g);
        if (!subject_format.ok) {
            return await utils.theend();
        }
        let text = utils.replaceDateTime(subject_format.data);
        if (text.includes("{name}")) {
            text = text.replace(/\{name}/g, (await utils.get_field("输入名称：", "email_name", true, true)).data)
        }
        if (text.includes("{receivers}")) {
            text = text.replace(/\{receivers}/g, (await utils.get_field("输入收件者名称：", "receivers", true, true)).data)
        }
        subject_input.focus()
        subject_input.value = text;

        let table = form.closest("table");

        let message_box; // 正文
        {
            let n;
            while (!n) {
                await utils.sleep(200)
                if (await utils.checkstop()) {
                    return;
                }
                n = utils.xpath_onlyone_visible("//div[@aria-label='Message Body']", table)
            }
            utils.scrollToElement(n)
            utils.highlight(n, true)
            await utils.sleep(200)
            message_box = n;
        }
        message_box.focus()
        message_box.click()
        message_box.textContent = text
        // utils.highlight(message_box, false)


        { // 附件
            // await simulateDragAndDrop(files.data, message_box)
            await utils.simulateDragAndDrop(files.data, message_box)
        }

        let send_btn = utils.xpath_onlyone_visible("//div[text()='Send' or text()='发送' or text()='發送']", table,)
        utils.scrollToElement(send_btn)
        utils.highlight(send_btn, true)
        await utils.sleep(200)
        // send_btn.click()
        // await utils.sleep(2000)

    }


    await utils.request_customizing("controls", { // 通知发送完毕，可能还有其他要发的，没有了的话由control把account的状态改为已发信
        action: "发件状态变化", status: "已发信", files,
    })

    await utils.theend();

}


main()

var triggerDragAndDrop = function (source, target, offsetY = 0) {
    var DELAY_INTERVAL_MS = 100;
    var MAX_TRIES = 10;
    var dragStartEvent;

    function createNewDataTransfer() {
        var data = {};
        return {
            clearData: function (key) {
                if (key === undefined) {
                    data = {};
                } else {
                    delete data[key];
                }
            }, getData: function (key) {
                return data[key];
            }, setData: function (key, value) {
                data[key] = value;
            }, setDragImage: function () {
            }, dropEffect: 'move', files: [], items: [], types: ['text/plain'], effectAllowed: 'move'
        }
    };var fireDragEvent = function (type, elem, clientX, clientY, dataTransfer) {
        let event = new DragEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: clientX,
            clientY: clientY,
            pageX: clientX,
            pageY: clientY,
            screenX: clientX,
            screenY: clientY,
            relatedTarget: elem
        });
        if (dataTransfer) {
            event.dataTransfer = dataTransfer;
        }
        console.log(222222222, event)
        elem.dispatchEvent(event);
        console.log(222222222, event)
        return event;
    }
    var firePointerEvent = function (type, elem, clientX, clientY) {
        let event = new PointerEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            pageX: clientX,
            pageY: clientY,
            screenX: clientX,
            screenY: clientY,
            button: 0,
            which: 1
        });
        event.preventDefault()
        elem.dispatchEvent(event)
    }
    var firePointerMoveEvent = function (type, elem, clientX, clientY) {
        let event = new PointerEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            pageX: clientX,
            pageY: clientY,
            screenX: clientX,
            screenY: clientY,
        });
        event.preventDefault()
        elem.dispatchEvent(event)
    }
    var fireMouseMoveEvent = function (type, elem, clientX, clientY) {
        var event = new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            pageX: clientX,
            pageY: clientY,
            screenX: clientX,
            screenY: clientY,
        });
        event.preventDefault()
        elem.dispatchEvent(event)
    }
    var fireMouseEvent = function (type, elem, clientX, clientY) {
        var event = new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            button: 0,
            view: window,
            pageX: clientX,
            pageY: clientY,
            screenX: clientX,
            screenY: clientY,
            which: 1
        });
        event.preventDefault()
        elem.dispatchEvent(event)
    }
    // fetch target elements
    var elemDrag = source
    var elemDrop = target
    if (!elemDrag || !elemDrop) return false;

    // calculate positions
    var pos = elemDrag.getBoundingClientRect()
    var center1X = Math.floor((pos.left + (pos.width / 2)))
    var center1Y = Math.floor((pos.top + (pos.height / 2)))
    pos = elemDrop.getBoundingClientRect()
    var center2X = Math.floor((pos.left + (pos.width / 2)))
    var center2Y = pos.bottom
    var counter = 0;
    var startingDropRect = elemDrop.getBoundingClientRect();

    function rectsEqual(r1, r2) {
        return r1.top === r2.top && r1.right === r2.right && r1.bottom === r2.bottom && r1.left === r2.left;
    }

    function dragover() {
        counter++;
        console.log('DRAGOVER #' + counter);

        var currentDropRect = elemDrop.getBoundingClientRect();
        if (rectsEqual(startingDropRect, currentDropRect) && counter < MAX_TRIES) {
            if (counter != 1) console.log("drop target rect hasn't changed, trying again");

            fireDragEvent("dragover", elemDrop, center2X, center2Y + offsetY, dragStartEvent.dataTransfer)
            fireMouseMoveEvent("mousemove", elemDrop, center2X, center2Y + offsetY)
            firePointerMoveEvent("pointermove", elemDrop, center2X, center2Y + offsetY)
            setTimeout(dragover, DELAY_INTERVAL_MS);
        } else {
            if (rectsEqual(startingDropRect, currentDropRect)) {
                console.log("wasn't able to budge drop target after " + MAX_TRIES + " tries, aborting");
                fireDragEvent("drop", elemDrop, center2X, center2Y + offsetY, dragStartEvent.dataTransfer)
                fireMouseEvent("mouseup", elemDrop, center2X, center2Y + offsetY)
                firePointerEvent("pointerup", elemDrop, center2X, center2Y + offsetY)

            } else {
                setTimeout(drop, DELAY_INTERVAL_MS);
            }
            setTimeout(drop, DELAY_INTERVAL_MS);
        }
    }

    function drop() {
        console.log('DROP');
        fireDragEvent("drop", elemDrop, center2X, center2Y + offsetY, dragStartEvent.dataTransfer)
        fireMouseEvent("mouseup", elemDrop, center2X, center2Y + offsetY)
        firePointerEvent("pointerup", elemDrop, center2X, center2Y + offsetY)

    }

    // start dragging process
    console.log('DRAGSTART');

    firePointerEvent("pointerdown", elemDrag, center1X, center1Y);
    fireMouseEvent("mousedown", elemDrag, center1X, center1Y)
    dragStartEvent = fireDragEvent("dragstart", elemDrag, center1X, center1Y,)

    setTimeout(dragover, DELAY_INTERVAL_MS);
    return true
}


async function simulateDragAndDrop(files, target) {
    let dataTransfer = new DataTransfer();
    dataTransfer.effectAllowed = "move";
    // dataTransfer.dropEffect = 'move';

    for (const file of files) {
        dataTransfer.items.add(file);
    }
    console.log(dataTransfer)

    // target.addEventListener("drop", (e) => {
    //     utils.log("target-drop", e, e.dataTransfer.items[0], e.dataTransfer.files)
    // })

    let body = document.querySelector("body");
    body.insertAdjacentHTML("beforeend", `
<button draggable="true" id="at-draggable-button">drag</button>
<style>
#at-draggable-button{
    position: fixed;
    top: 0;
    left: 0;
    width: 48px;
    height: 48px;
    z-index: 9999;
}
</style>`)
    let lastDataTransfer;
    let drag_btn = body.querySelector("#at-draggable-button");
    drag_btn.addEventListener('dragstart', function (event) {
        // const fileContent = new Blob(["Hello, this is a test file!"], {type: "text/plain"});
        // const file = new File([fileContent], "test.txt", {type: "text/plain"});
        // event.dataTransfer.items.add(file);
        event.dataTransfer = new DataTransfer()
        for (const file of files) {
            event.dataTransfer.items.add(file);
        }
        lastDataTransfer = event.dataTransfer
        lastDataTransfer.types = ["application/x-moz-file", ...lastDataTransfer.types,]
    });
    // return triggerDragAndDrop(drag_btn, target,)
    // return

    async function simulateDragAndDrop() {
        // 1. 触发 dragstart，让浏览器创建 dataTransfer
        const dragStartEvent = new Event("dragstart", {bubbles: true, cancelable: true});
        drag_btn.dispatchEvent(dragStartEvent);

        while (!lastDataTransfer) {
            await utils.sleep(200)
        }

        const dragEnterEvent = new DragEvent("dragenter", {
            bubbles: true, cancelable: true, dataTransfer: lastDataTransfer,
        });
        target.dispatchEvent(dragEnterEvent);
        await utils.sleep(2000)
        const dragOverEvent = new DragEvent("dragover", {
            bubbles: true, cancelable: true, dataTransfer: lastDataTransfer,
        });
        target.dispatchEvent(dragOverEvent);
        await utils.sleep(2000)
        const dropEvent = new DragEvent("drop", {
            bubbles: true, cancelable: true, dataTransfer: lastDataTransfer,
        });
        console.log("原始drop", files[0]._drop_event)
        utils.log("drop事件", dropEvent)
        target.dispatchEvent(dropEvent);
    }

    await simulateDragAndDrop()
    return


    const rect = target.getBoundingClientRect();
    let centerX = rect.left + rect.width / 2;
    let centerY = rect.top + rect.height / 2;
    // centerX = centerX + Math.floor(Math.random() * (10 + 1 - 1)) + 1;
    // centerY = centerY + Math.floor(Math.random() * (10 + 1 - 1)) + 1;
    utils.log(rect, centerX, centerY)

    const dragEnterEvent = new DragEvent("dragenter", {
        bubbles: true, cancelable: true, dataTransfer: dataTransfer, clientX: centerX, clientY: centerY
    });
    target.dispatchEvent(dragEnterEvent);
    await utils.sleep(2000)
    const dragOverEvent = new DragEvent("dragover", {
        bubbles: true, cancelable: true, dataTransfer: dataTransfer, clientX: centerX, clientY: centerY
    });
    target.dispatchEvent(dragOverEvent);
    await utils.sleep(2000)
    // target.dispatchEvent(new MouseEvent("mousemove", {
    //     bubbles: true, cancelable: true, clientX: 100, clientY: 100, button: 0,
    // }));
    // await utils.sleep(2000)
    const dropEvent = new DragEvent("drop", {
        bubbles: true, cancelable: true, dataTransfer: dataTransfer, clientX: centerX, clientY: centerY
    });
    console.log("原始drop", files[0]._drop_event)
    utils.log("drop事件", dropEvent)
    target.dispatchEvent(dropEvent);

    // target.dispatchEvent(files[0]._drop_event);

    // {
    //     let target2 = utils.xpath_onlyone_visible("//div[contains(text(), 'Drop to attach')]", document)
    //     // const dragEnterEvent = new DragEvent("dragenter", {
    //     //     bubbles: true, cancelable: true, dataTransfer: dataTransfer
    //     // });
    //     // target2.dispatchEvent(dragEnterEvent);
    //     // await utils.sleep(2000)
    //     const dragOverEvent = new DragEvent("dragover", {
    //         bubbles: true, cancelable: true, dataTransfer: dataTransfer
    //     });
    //     target2.dispatchEvent(dragOverEvent);
    //     await utils.sleep(2000)
    //     // target2.dispatchEvent(new MouseEvent("mousemove", {
    //     //     bubbles: true, cancelable: true, clientX: centerX, clientY: centerY, button: 0,
    //     // }));
    //     // await utils.sleep(2000)
    //     const dropEvent = new DragEvent("drop", {
    //         bubbles: true, cancelable: true, dataTransfer: dataTransfer
    //     });
    //     target2.dispatchEvent(dropEvent);
    // }


}
