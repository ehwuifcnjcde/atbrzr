async function main() {

    await utils.update({
        current: {
            flow: content_script_env["flow_name"], script: content_script_env["script_name"],
        },
    });

    if (await utils.checkstop()) {
        return;
    }

    // utils.log(content_script_env)

    await utils.request_customizing("controls", {
        action: "状态变化", status: "正在收信",
    })

    // 进入收件箱
    let inbox_node;
    {
        let xpath = "//div/span/a[text()='Inbox' or text()='收件箱' or text()='收件匣']";
        let node = utils.xpath_onlyone(xpath, document)
        if (!node) {
            return await utils.theend();
        } else {
            utils.highlight(node,)
            node.click();
            await utils.sleep(1000)
            inbox_node = node
            utils.highlight(node, false)
        }
    }

    let auto_delete = {data: true};
    while (true) {
        if (!auto_delete.data) {
            break
        }
        // let items = document.querySelectorAll("table tbody tr td[data-tooltip='Select']");
        let nodes = utils.xpath_findall("//table/tbody/tr/td[@data-tooltip='Select' or @data-tooltip='选择' or @data-tooltip='選取']", document, true)
        // utils.log(nodes)
        let nodes_tr = []; // 信件列表
        for (let i = 0; i < nodes.length; i++) {
            let item = nodes[i]
            // console.log(1111, item)
            item = item.closest("tr")
            // console.log(2222, item)
            nodes_tr.push(item)
        }
        if (nodes_tr.length === 0) {
            break
        }
        utils.log(nodes_tr)
        for (let i = 0; i < nodes_tr.length; i++) {
            let item = nodes_tr[i]
            utils.highlight(item, false)
        }
        for (let i = 0; i < nodes_tr.length; i++) {
            let item = nodes_tr[i]
            utils.highlight(item,)
            utils.scrollToElement(item)
            await utils.sleep(200)
            let name_span = item.querySelector("td div span[email]") // 单个信件的名称列
            if (!name_span) {
            } else {
                name_span.closest("div").click();
            }
            let can_delete;
            {
                let reply_btn;
                let nodes, _ = 0; // 检查有没有附件
                while (!nodes && _ < 30) {
                    _++;
                    nodes = utils.xpath_findall("//div[contains(@data-message-id, 'msg-')]//span[contains(text(), 'attachment') or contains(text(), '附')]", document)
                    if (nodes.snapshotLength === 0) {
                        nodes = null;
                    }
                    if (_ > 10) {
                        reply_btn = utils.xpath_onlyone_visible("//table[@role='presentation']//td//div/span[text()='Reply' or text()='回复' or text()='回復' or text()='回覆']", document,)
                        if (reply_btn) {
                            utils.scrollToElement(reply_btn)
                            utils.highlight(reply_btn)
                            _ += 2
                        }
                    }
                    await utils.sleep(200)
                    if (await utils.checkstop()) {
                        return;
                    }
                }
                utils.log("有没有附件", nodes)
                if (nodes?.snapshotLength > 0) {
                    let nodes = utils.xpath_findall("//div/span/button[contains(@aria-label, 'Download attachment') or contains(@aria-label, '下载附') or contains(@aria-label, '下載附')]", document)
                    utils.log("下载按钮", nodes)
                    for (let i = 0; i < nodes.snapshotLength; i++) {
                        // continue
                        let node = nodes.snapshotItem(i)
                        utils.scrollToElement(node)
                        utils.highlight(node)
                        if (i === 0) {
                            await utils.sleep(4000)
                        } else {
                            await utils.sleep(3000)
                        }
                        await utils.sleep(200)
                        const event = new Event("mouseover", {bubbles: true, cancelable: true});
                        node.dispatchEvent(event);
                        // const mouseOverEvent = new MouseEvent("mouseover", { // 也行
                        //     bubbles: true, cancelable: true, view: window
                        // });
                        await utils.sleep(200)
                        node.click()
                        await utils.sleep(200)
                        // utils.highlight(node, false)
                        if (i === nodes.snapshotLength - 1) {
                            await utils.sleep(2000)
                        }
                    }

                    const reply_msg = await utils.get_field("输入回复：", "reply_msg", true, true);// 回复ok
                    if (!reply_msg.ok) {
                        return await utils.theend();
                    } else if (reply_msg.data.length === 0) { // 不回复

                    } else {
                        reply_btn = utils.xpath_onlyone_visible("//table[@role='presentation']//td//div/span[text()='Reply' or text()='回复' or text()='回復' or text()='回覆']", document,)
                        if (reply_btn) {
                            utils.scrollToElement(reply_btn)
                            utils.highlight(reply_btn)
                            _ += 5
                        }
                        utils.scrollToElement(reply_btn)
                        utils.highlight(reply_btn, false)
                        await utils.sleep(200)
                        reply_btn.click()

                        let reply_textarea;
                        while (!reply_textarea) {
                            await utils.sleep(200)
                            if (await utils.checkstop()) {
                                return;
                            }
                            reply_textarea = utils.xpath_onlyone_visible("//table[@role='presentation']//table//tr//td//div[@role='textbox']", document,)
                            utils.log("reply_textarea", reply_textarea)
                        }
                        utils.scrollToElement(reply_textarea)
                        await utils.sleep(200)
                        reply_textarea.click()
                        await utils.sleep(50)
                        let text = utils.replaceDateTime(reply_msg.data);
                        if (text.includes("{name}")) {
                            text = text.replace(/\{name}/g, (await utils.get_field("输入名称：", "email_name", true, true)).data)
                        }
                        reply_textarea.textContent = text;
                        await utils.sleep(50)

                        let reply_send_btn;
                        while (!reply_send_btn) {
                            await utils.sleep(200)
                            if (await utils.checkstop()) {
                                return;
                            }
                            reply_send_btn = utils.xpath_onlyone_visible("//table[@role='presentation']//table//tr//td//div[text()='Send' or text()='发送' or text()='發送' or text()='傳送']", document,)
                            utils.log("reply_send_btn", reply_send_btn)
                        }
                        utils.highlight(reply_send_btn)
                        utils.scrollToElement(reply_send_btn)
                        await utils.sleep(200)
                        reply_send_btn.click()
                        await utils.sleep(1000)
                        utils.highlight(reply_send_btn, false)
                        while (utils.isElementVisible(reply_send_btn)) {
                            await utils.sleep(200)
                            if (await utils.checkstop()) {
                                return;
                            }
                        }

                    }

                } else {
                    utils.highlight(reply_btn, false)
                }

                if (reply_btn) {
                    can_delete = true
                }
            }


            // utils.highlight(item, false)

            // { // 选不到Back to Inbox按钮
            //     await utils.sleep(2000)
            //     let xpath = "//div[contains(@role, 'button')]";
            //     let nodes = utils.xpath_findall(xpath, document)
            //     for (let i = 0; i < nodes.snapshotLength; i++) {
            //         let node = nodes.snapshotItem(i)
            //         console.log(node.getAttribute("aria-label"))
            //     }
            //     let node = utils.xpath_onlyone(xpath, document)
            //     if (!node) {
            //         return await utils.theend();
            //     } else {
            //         node.click();
            //         await utils.sleep(1000)
            //     }
            // }
            utils.highlight(inbox_node,)
            utils.scrollToElement(inbox_node)
            await utils.sleep(200)
            inbox_node.click()
            await utils.sleep(1500)
            utils.highlight(inbox_node, false)

            if (can_delete) { // 移至垃圾桶
                auto_delete = await utils.get_field_bool("是否删信？", "auto_delete", true,);
                if (!auto_delete.ok) {
                    return await utils.theend();
                }
                if (auto_delete.data) {
                    {
                        const event = new Event("mouseover", {bubbles: true, cancelable: true});
                        item.dispatchEvent(event);
                    }
                    let delete_btn;
                    while (!delete_btn) {
                        await utils.sleep(200)
                        if (await utils.checkstop()) {
                            return;
                        }
                        delete_btn = utils.xpath_onlyone(".//td/ul/li[@data-tooltip='Delete' or @data-tooltip='删除' or @data-tooltip='刪除']", item,)
                    }
                    utils.log("delete_btn", delete_btn)
                    utils.highlight(delete_btn)
                    utils.scrollToElement(delete_btn)
                    await utils.sleep(200)
                    const event = new Event("mouseover", {bubbles: true, cancelable: true});
                    delete_btn.dispatchEvent(event);
                    await utils.sleep(400)
                    delete_btn.click()
                    await utils.sleep(1000)
                }
            }

            // return await utils.theend();

        }
    }


    await utils.request_customizing("controls", {
        action: "状态变化", status: "已收信",
    })


    await utils.theend();

}


main()


