async function main() {
    document.querySelector("#input-text").value = "Hello ";
    document.querySelector("#btn-confirm").click()
    await sleep(4000)
    document.querySelector("#input-text").value = " World";
    document.querySelector("#btn-confirm").click()
    await sleep(4000)
    document.querySelector("#input-text").value = "Hello World";
    document.querySelector("#btn-confirm").click()
}


main()

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}