async function main() {
    document.querySelector("#input-text").value = "Hello World";
    document.querySelector("#btn-confirm").click()
    document.querySelector("#input-text").value = "Hello World";
    document.querySelector("#btn-confirm").click()
    document.querySelector("#btn-confirm").click()
}


main()